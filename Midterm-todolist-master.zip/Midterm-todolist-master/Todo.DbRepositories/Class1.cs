﻿namespace Todo.DbRepositories
{
    public class Class1
    {

    }
}
